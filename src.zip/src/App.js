import React from "react";
import WebSSH from "./components/webssh";

function App() {
    return (
        <div className="App">
            <WebSSH />
        </div>
    );
}

export default App;
