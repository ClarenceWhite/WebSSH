import React, { useEffect, useRef } from "react";
import { Terminal } from "xterm";
import "xterm/css/xterm.css";
import WSSHClient from './wsshclient';

function WebSSH() {
    const terminalRef = useRef(null);

    useEffect(() => {
        openTerminal({
            operate: "connect",
            host: "10.211.55.45",
            port: "22", //端口号
            username: "root", //用户名
            password: "admin" //密码
        });
    }, []);

    function openTerminal(options) {
        var client = new WSSHClient();
        var term = new Terminal({
            cols: 97,
            rows: 37,
            cursorBlink: true, // 光标闪烁
            cursorStyle: "block", // 光标样式  null | 'block' | 'underline' | 'bar'
            scrollback: 800, //回滚
            tabStopWidth: 8, //制表宽度
            screenKeys: true
        });

        term.onData((data) => {
            client.sendClientData(data);
        });

        term.open(terminalRef.current);

        //在页面上显示连接中...
        term.write("Connecting...");

        //执行连接操作
        client.connect({
            onError: function (error) {
                //连接失败回调
                term.write("Error: " + error + "\r\n");
            },
            onConnect: function () {
                //连接成功回调
                client.sendInitData(options);
            },
            onClose: function () {
                //连接关闭回调
                term.write("\rconnection closed");
            },
            onData: function (data) {
                //收到数据时回调
                term.write(data);
            }
        });
    }

    return <div ref={terminalRef} style={{ width: "100%", height: "100%" }} />;
}

export default WebSSH;
